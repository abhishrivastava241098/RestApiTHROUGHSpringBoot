package com.springrestemp.springrestemp.enities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {

	@Id
	private long id;
	private String name;
	private String address;
	private String education;
	private long contactno;
	
	public Employee(long id, String name, String address, String education, long contactno) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.education = education;
		this.contactno = contactno;
	}
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public long getContactno() {
		return contactno;
	}
	public void setContactno(long contactno) {
		this.contactno = contactno;
	}
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", address=" + address + ", education=" + education
				+ ", contactno=" + contactno + "]";
	}
	
	
}
