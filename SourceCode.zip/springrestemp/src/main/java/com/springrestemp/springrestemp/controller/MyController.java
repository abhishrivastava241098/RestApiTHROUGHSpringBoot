package com.springrestemp.springrestemp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springrestemp.springrestemp.enities.Employee;
import com.springrestemp.springrestemp.services.EmployeeService;

@RestController
public class MyController {

	@Autowired
	private EmployeeService employeeservice;
	
	//get the employee
	
	@GetMapping("/employees")
	public List<Employee> getEmployees(){
		
		return this.employeeservice.getEmployees();
		
	}
	
	//get single employee
	
	@GetMapping("/employees/{employeeId}")
	public Employee getEmployee(@PathVariable String employeeId ) {
		
		return this.employeeservice.getEmployee(Long.parseLong(employeeId));
	}
	
	//add employees 
	
	@PostMapping("/employees")
	public Employee addEmployee(@RequestBody Employee employee) {
		return this.employeeservice.addEmployee(employee);
	}
	
	//updating employee 
	@PutMapping("/employees")
	public Employee updateEmployee(@RequestBody Employee employee) {
		
		return this.employeeservice.updateEmployee(employee);			
	}
	
	//deleting employee
	@DeleteMapping("/employees/{employeeId}")
	public void deleteemployee(@PathVariable String employeeId )
	{	
		
		 this.employeeservice.deleteEmployee(Long.parseLong(employeeId));
	} 
}

